
public class Pair<X,Y> implements Comparable<Pair<X,Y>>{
	X first;
	Y second;
	Pair( X first, Y second){
		this.first=first;
		this.second=second;
	}
	public X getFirst() {
		return first;
	}
	public Y getSecond() {
		return second;
	}
	public int compareTo(Pair p) {
		return 0;
	}
}
