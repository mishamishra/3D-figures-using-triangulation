
interface TriangleInterface {

	//Point1, Point2, Point3

	//[(x1,y1,z1),(x2,y2,z2),(x3,y3,z3)]

	// No specific order between points
	// MUST CONTAIN EXACTLY 3 points. 
    	PointInterface [] triangle_coord();

}

