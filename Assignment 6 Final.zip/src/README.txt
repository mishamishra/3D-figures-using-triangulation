I have implemented an ArrayList Class which functions the same as inbuilt ArrayList of java.

In Point Class, I have made an ArrayList of all triangles whose one vertex is that point. Also I made an Arraylist of Pair in which first componet is the outgoing edge and the second is the opposite point.

In Edge Class, I have made an ArrayList of all triangles whose one edge is that edge.

In triangle class, I have made an ArrayList which stores all the neighbours of that triangle.

In Shape class, I made an Array of edges, points and triangles and i used separate chaining for insertion and the data structure used is bst.
I also maintained  a list of all edges and triangles. I maintained an array list of type(Pair<ArrayList<Triangle>,ArrayList<Point>>) for storing all the connected components. the first list inside pair
stores all the triangles in the component and the second list contains all the points in the component).

ADD_TRIANGLE: I create a triangle using the given points(given if the points satisfy the non colinearity). Then i search if the points exist or not. If they exist, I update them to the already stored values. Same I do for edges. And in each of the points and edges
I add this triangle to their triangle list. I also add the neighbours of the created triangle in it's neighbors's list by traversing the triangle list of all the edges. I also update the pair list of all points.
Avg Time Complexity: O(max(loadfactor of points array,load factor of edge array)) as hashing is used.

TYPE_MESH(): I traverse through the list of all edges. If the triangle list of any edge has count>2, I return 3. Else, if count is 1 and no other edge had count>2 , i return 2. else i return 1.
Avg Time Complexity: O(no. of edges)

BOUNDARY_EDGES(): I traverse through the list of all edges, and return all those edges whose triangle list count=1.
Avg Time Complexity: O(no. of edges)

INCIDENT_TRIANGLES: I search for the point given and if the point exists. I return all the triangles in its triangles list.
Avg Time Complexity: O(no. of incident triangles) because i am putting the triangle one by one (by traversing the triangle list) in the new array.

TRIANGLE_NEIGHBOR_OF_EDGE:  I search for the edge given and if the edge exists. I return all the triangles in its triangles list.
Avg Time Complexity: O(no. of incident triangles of the given edge) because i am putting the triangle one by one (by traversing the triangle list) in the new array.

NEIGHBORS_OF_POINT: I search for the point given and if the point exists. I traverse through the pair list of that point and return all the neighbour points.
Avg Time Complexity: O(no. of neighbour points) 

VERTEX_NEIGHBOR_TRIANGLE: I search if the given triangle exists. If it does I return all it's coordinates.
Avg Time Complexity: O(1) 

EDGE_NEIGHBOR_TRIANGLE: I search if the given triangle exists. If it does I return all it's edges.
Avg Time Complexity: O(1) 

EDGE_NEIGHBORS_OF_POINT:  I search for the point given and if the point exists. I traverse through the pair list of that point and return all the outgoing edges.
Avg Time Complexity: O(no. of edge neighbours) 

FACE_NEIGHBORS_OF_POINT: same as INCIDENT_TRIANGLES

EXTENDED_NEIGHBOR_TRIANGLE: I search for the given triangle. if it exists, i returned all the triangles from the triangle list of all it's coordinates excluding duplicates in a sorted manner.
Avg Time Complexity: O(n*n) {n=no. of extended neighbour triangles} (I am adding the new triangle at the end of the list and then checking its insertion time with each of the previous added triangles and
swapping if the time is less).

NEIGHBORS_OF_TRIANGLE:  I search for the given triangle. if it exists, i returned all the triangles from the neighbour triangle list.
Avg Time Complexity: O(n*n) {n=no. ofneighbour triangles} (I am adding the new triangle at the end of the list and then checking its insertion time with each of the previous added triangles and
swapping if the time is less).

COUNT_CONNECTED_COMPONENTS(): I performed bst on the whole graph. My bst had a parameter (triangle t) from which i start my bst. my one call to bst traverse all the triangles whose component was 
same as the triangle given in the parameter. no. of bst operations performed were equal to the components. In the end i maintained a list of all the connected components.
Avg Time Complexity: O(no. of triangles)

CENTROID(): First I call connected components. and then I traverse through the list of all connected components and calculate centriod of each component by traversing through the array list of points.
Avg Time Complexity: O(no. of triangles)

CENTROID_OF_COMPONENT : First I call connected components. and then check that this point lies in which component and the calculate the centroid.
Avg Time Complexity: O(no. of triangles)

IS_CONNECTED: I check if the given triangles exist or not. then I performed bfs on any one of the triangle. if both the triangle lie in the same component, i return true.
Avg Time Complexity: O(no. of triangle neighbours of the triangle on which i performed bst)

CLOSEST_COMPONENTS(): for each component, I calculated the distance of all the vertices from all the vertices of the remaining components and return those points whose distance is min.
Avg Time Complexity: O(n) {n= no. of vertices}

MAXIMUM_DIAMETER(): I called connected_components(). and then i searched for the component having max number of triangles. the number of levels for that particular component's bst
is the max diameter. 
Avg Time Complexity: O(no. of triangles)


