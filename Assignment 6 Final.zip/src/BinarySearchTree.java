class Position<T,K> {
	T value;
	K key;
	Position<T,K> left;
	Position<T,K> right;
	Position(K key,T value,Position<T,K> left,Position<T,K> right){
		this.key=key;
		this.value=value;
		this.left=left;
		this.right=right;
	}

}
public class BinarySearchTree<T,K extends Comparable<K>>{
	Position<T,K> root;
	BinarySearchTree(K key, T value){
		root=new Position<T,K>(key,value,null,null);
	}
	public Position<T,K> search(K key,Position<T,K> root) {
		if(key.compareTo(root.key)==0) {
			return root;
		}
		else if(key.compareTo(root.key)<0) {
			if(root.left!=null) {
				return search(key,root.left);
			}
			else
				return root;
		}
		else {
		if (root.right!=(null)) {
			return search(key,root.right);
		}
		else
			return root;
		}
		}
	public void insert(K key,T obj){
		Position<T,K> pos= search(key,root);
		if(key.compareTo(pos.key)==0) {
			return;
		}
		if(key.compareTo(pos.key)<0) {
			pos.left= new Position<T,K>(key,obj,null,null);
			return;
			
		}
		else {
			pos.right= new Position<T,K>(key,obj,null,null);
			return;
		}
	}
/*	public int update(K key1,K key2,T obj) {
		s="";
		Position<T,K> pos= search(key1,key2,root);
		if(pos.key1.equals(key1)&&pos.key2.equals(key2)) {
			pos.value=obj;
			return s.length()+1;
		}
		else
			return 0;
		}
	public int delete(K key1,K key2) {
		Position<T,K> parent = null;
		Position<T,K> curr = root;
		int i=1;
		while (curr != null &&! (curr.key1.equals(key1)&&curr.key2.equals(key2)))
		{
			parent = curr;
					if(curr.key1.equals(key1)) {
						if (curr.key2.toString().compareTo(key2.toString()) > 0) {
							curr=curr.left;
							i++;
					}
						else {
							curr=curr.right;
							i++;
						}
					}
					else if (curr.key1.toString().compareTo(key1.toString()) > 0) {
						curr = curr.left;
						i++;
					}
					else {
						curr = curr.right;
						i++;
					}
				}
				if (curr == null) {
					return 0;
				}
				if (curr.left == null && curr.right == null)
				{
					if (!curr.equals(root)) {
						if (parent.left == curr) {
							parent.left = null;
						} else {
							parent.right = null;
						}
					}
					else {
						root = null;
					}
				}
				else if (curr.left != null && curr.right != null)
				{
					Position<T,K> successor  = curr.right;
					while(successor.left!=null) {
						successor=successor.left;
						i++;
					}
					K tkey1 = successor.key1;
					K tkey2 = successor.key2;
					T tvalue = successor.value;
					if(s1.equals("T")) {
					j=i;
					}
					s1="F";
					delete(tkey1,tkey2);
					curr.key1 = tkey1;
					curr.key2=tkey2;
					curr.value=tvalue;
				}
				else
				{
					Position<T,K> child = (curr.left != null)? curr.left: curr.right;
					if (!curr.equals(root))
					{
						if (curr == parent.left) {
							parent.left = child;
							i++;
						} else {
							parent.right = child;
							i++;
						}
					}
					else {
						root = child;
						i++;
					}
				}
				if(s1.equals("T"))
				return i;
				else
					return j;
			}
	public T get(K key1,K key2) {
		s="";
		Position<T,K> pos= search(key1,key2,root);
		if(pos.key1.equals(key1)&&pos.key2.equals(key2)) {
			return pos.value;
		}
		else
			return null;
		}
	public String address(K key1,K key2) {
		s="";
		Position<T,K> pos= search(key1,key2,root);
		if(pos.key1.equals(key1)&&pos.key2.equals(key2)) {
			return s;
		}
		else return null;
		}*/
	

}
