public class ArrayList<T>{
    T array[]; 
    int count; 
    int size;  
    int levels=0;
    public ArrayList() 
    { 
        array = (T[]) new Object[1]; 
        count = 0; 
        size = 1; 
    } 
    public void add(T data) 
    {  
        if (count == size) { 
            growSize();
        }
        array[count] = data; 
        count++; 
    }
    public void growSize(){ 
  
        T temp[] = null; 
        if (count == size) {
            temp =(T[]) new Object[size+1]; 
            { 
                for (int i = 0; i < size; i++) {
                    temp[i] = array[i]; 
                } 
            } 
        }
        array = temp;
        size = size+1; 
    }
  
    public void set(int index, T data) 
    {
    	array[index]=data;
    }
    public T get(int index) 
    {
    	return array[index];
    }
    public void remove() 
    { 
        if (count > 0) { 
            array[count - 1] = null; 
            count--; 
            shrinkSize();
        } 
    } 
    public void shrinkSize() 
    { 
        T temp[] = null; 
        if (count > 0) {
            temp = (T[]) new Object[count]; 
            for (int i = 0; i < count; i++) {
                temp[i] = array[i]; 
            } 
  
            size = count;
            array = temp; 
        } 
    }
    public boolean contains(T data) {
    	for(int i=0;i<count;i++) {
    		if(array[i].equals(data)==true) {
    			return true;
    		}
    	}
    	return false;
    }
    } 