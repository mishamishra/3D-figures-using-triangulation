
public class Point implements PointInterface, Comparable<Point>{
	 public static int mod(int num) {
		 if(num<0) {
			 return (-1)*num;
		 }
		 else {
			 return num;
		 }
	 }
	 public static float sq(float num) {
		 return num*num;
		 }
	float x,y,z;
	int count=0;
	int component;
	ArrayList<Pair<Edge,Point>> list=new ArrayList();
	ArrayList<Triangle> tlist= new ArrayList();
	Point(float x,float y,float z){
		this.x=x;
		this.y=y;
		this.z=z;
	}
	public float getX() {
		  return x;
	  }
	public float getY() {
		   return y;
	   }
	public float getZ() {
		   return z;
	   }
	public float [] getXYZcoordinate() {
	    	float[] coordinates= {x,y,z};
	    	return coordinates;
	    }
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(x);
		result = prime * result + Float.floatToIntBits(y);
		result = prime * result + Float.floatToIntBits(z);
		return mod(result);
	}
	
	public boolean equals(Point p) {
		if(this.x==p.x&&this.y==p.y&&this.z==p.z) {
			return true;
			}
		return false;
	}
	public String toString() {
		   return "["+x+","+y+","+z+"]";
	   }
	double length(Point p) {
		return Math.sqrt(sq(p.x-this.x)+sq(p.y-this.y)+sq(p.z-this.z));
	}
	public int compareTo(Point p) {
		if(this.x==p.x&&this.y==p.y&&this.z==p.z) {
			return 0;
			}
		else if(this.x!=p.x) {
			return (int)this.x-(int)p.x;
			}
		else if(this.y!=p.y) {
			return (int)this.y-(int)p.y;
			}
		else {
			return (int)this.z-(int)p.z;
		}
		}
	
}
