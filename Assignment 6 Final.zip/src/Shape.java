public class Shape implements ShapeInterface{
	BinarySearchTree<Point,Point>[] parray= new BinarySearchTree[769];
	BinarySearchTree<Edge,Edge>[] earray= new BinarySearchTree[769];
	BinarySearchTree<Triangle,Triangle>[] tarray= new BinarySearchTree[769];
	ArrayList<Edge> elist= new ArrayList<Edge>();
	ArrayList<Triangle> tlist= new ArrayList<Triangle>();
	ArrayList<Pair<ArrayList<Triangle>,ArrayList<Point>>> conn_comp1= new ArrayList<Pair<ArrayList<Triangle>,ArrayList<Point>>>();
	static int  not=0;
	static int isconn=0;
	static int BFScount=0;
	static int component=0;
	 public static float sq(float num) {
		 return num*num;
		 }
	 public static float sqrt(float num) {
		 float temp;
		 float sr = num / 2;
		 do {
			 temp = sr;
				sr = (temp + (num / temp)) / 2;
			} while ((temp - sr) != 0);
		 return sr;
	 }
	 public static int mod(int num) {
		 if(num<0) {
			 return (-1)*num;
		 }
		 else {
			 return num;
		 }
	 }
	 public static float modf(float num) {
		 if(num<0) {
			 return (-1)*num;
		 }
		 else {
			 return num;
		 }
	 }
	 public static Pair<ArrayList<Triangle>,ArrayList<Point>> BFS(Triangle t) {
		 ArrayList<Triangle> known= new ArrayList<Triangle>();
		 ArrayList<Triangle> level= new ArrayList<Triangle>();
		 ArrayList<Point> point= new ArrayList<Point>();
		 known.add(t);
		 level.add(t);
		 int levels=0;
		 t.count=BFScount;
		 t.component=component;
		 PointInterface[] tpoint= t.triangle_coord();
		 for(int x=0;x<3;x++) {
			 point.add((Point)tpoint[x]);
			 ((Point)tpoint[x]).count=BFScount;
		 }
		 t.p1.component=component;
		 t.p2.component=component;
		 t.p3.component=component;
		 while(level.count!=0) {
			 ArrayList<Triangle> nextlevel= new ArrayList<Triangle>(); 
			 int i=0;
			 while(i<level.count) {
			 Triangle pos= level.get(i);
			 for(int j=0;j<pos.list.count;j++) {
				 Triangle t1=pos.list.get(j);
				 if(t1.count==BFScount) {
				 }
				 else {
					 t1.p1.component=component;
					 t1.p2.component=component;
					 t1.p3.component=component;
					 PointInterface[] t1point= t1.triangle_coord();
					 for(int k=0;k<3;k++) {
						 if(((Point)t1point[k]).count!=BFScount) {
						 point.add((Point)t1point[k]);
						 ((Point)t1point[k]).count=BFScount;
						 }
					 }
					 t1.count=BFScount;
					 t1.component=component;
					 known.add(t1);
					 nextlevel.add(t1);
				 }
			 }
			 i++;
			 }
			 level=nextlevel;
			 if(level.count>0) {
				 levels++;
			 }
		 }
		 known.levels=levels;
		 Pair<ArrayList<Triangle>,ArrayList<Point>> p= new Pair<ArrayList<Triangle>,ArrayList<Point>>(known,point);
		 return p;
	 }
	 public boolean ADD_TRIANGLE(float [] triangle_coord){
		 Point p1= new Point(triangle_coord[0],triangle_coord[1],triangle_coord[2]);
		 Point p2= new Point(triangle_coord[3],triangle_coord[4],triangle_coord[5]);
		 Point p3= new Point(triangle_coord[6],triangle_coord[7],triangle_coord[8]);
		 boolean[] fp= {false,false,false};
		 boolean[] fe= {false,false,false};
		 Edge e1=new Edge(p3,p2);
		 Edge e2=new Edge(p1,p3);
		 Edge e3=new Edge(p1,p2);
		 Edge[] e= {e1,e2,e3};
		 float[] a= {triangle_coord[0]-triangle_coord[3],triangle_coord[1]-triangle_coord[4],triangle_coord[2]-triangle_coord[5]};
		 float[] b= {triangle_coord[0]-triangle_coord[6],triangle_coord[1]-triangle_coord[7],triangle_coord[2]-triangle_coord[8]};
		 float c=((a[0]*b[0])+(a[1]*b[1])+(a[2]*b[2]))/(sqrt(sq(a[0])+sq(a[1])+sq(a[2]))*sqrt(sq(b[0])+sq(b[1])+sq(b[2])));
		 float d=sqrt(1-sq(c));
		 float tan= modf(d/c);
		 if(tan>0.001) {
			 not++;
			 Triangle t= new Triangle(p1,p2,p3);
			 tlist.add(t);
			 int hash=mod((t.hashCode()%tarray.length));
			 if(tarray[hash]==null) {
				 tarray[hash]= new BinarySearchTree(t,t);
			 }
			 else {
				 tarray[hash].insert(t,t); 
			 }
			 for(int i=0; i<3; i++) {
				 int hashcode= mod((t.triangle_coord()[i].hashCode())%parray.length);
				 if(parray[hashcode]==null) {
					 parray[hashcode]= new BinarySearchTree((Point)t.triangle_coord()[i],(Point)t.triangle_coord()[i]);
					 ((Point)t.triangle_coord()[i]).tlist.add(t);
				 }
				 else {
					 Position<Point,Point> p=parray[hashcode].search((Point)t.triangle_coord()[i],parray[hashcode].root);
					 if(p.key.compareTo((Point)t.triangle_coord()[i])==0) {
						 fp[i]=true;
						 p.value.tlist.add(t);
					 }
					 else {
						 parray[hashcode].insert((Point)t.triangle_coord()[i],(Point)t.triangle_coord()[i]);
						 ((Point)t.triangle_coord()[i]).tlist.add(t);
					 }
				 }
			 }
			 if((fp[0]==false&&fp[1]==false&&fp[2]==false)||(fp[0]==true&&fp[1]==false&&fp[2]==false)||(fp[0]==false&&fp[1]==false&&fp[2]==true)||(fp[0]==false&&fp[2]==false&&fp[1]==true)) {
				 for(int i=0; i<3; i++) {
					 int hashcode= mod((e[i].hashCode())%parray.length);
					 if(earray[hashcode]==null) {
						earray[hashcode]= new BinarySearchTree(e[i],e[i]);
						elist.add(e[i]);
						e[i].tlist.add(t);
					 }
					 else {
							 earray[hashcode].insert(e[i],e[i]);
							 elist.add(e[i]);
							 e[i].tlist.add(t);
					 }
				 }
				 if(fp[0]==true) {
					int hashcode= mod((p1.hashCode())%parray.length); 
					p1=parray[hashcode].search(p1,parray[hashcode].root).value;
					p1.list.add(new Pair<Edge,Point>(e3,p2));
					 p1.list.add(new Pair<Edge,Point>(e2,p3));
					 p2.list.add(new Pair<Edge,Point>(e1,p3));
					 p2.list.add(new Pair<Edge,Point>(e3,p1));
					 p3.list.add(new Pair<Edge,Point>(e1,p2));
					 p3.list.add(new Pair<Edge,Point>(e2,p1));
				 }
				 else if(fp[1]==true) {
						int hashcode= mod((p2.hashCode())%parray.length); 
						p2=parray[hashcode].search(p2,parray[hashcode].root).value;
						p1.list.add(new Pair<Edge,Point>(e3,p2));
						 p1.list.add(new Pair<Edge,Point>(e2,p3));
						 p2.list.add(new Pair<Edge,Point>(e1,p3));
						 p2.list.add(new Pair<Edge,Point>(e3,p1));
						 p3.list.add(new Pair<Edge,Point>(e1,p2));
						 p3.list.add(new Pair<Edge,Point>(e2,p1));
					 }
				 else if(fp[2]==true) {
						int hashcode= mod((p3.hashCode())%parray.length); 
						p3=parray[hashcode].search(p3,parray[hashcode].root).value;
						p1.list.add(new Pair<Edge,Point>(e3,p2));
						p1.list.add(new Pair<Edge,Point>(e2,p3));
						 p2.list.add(new Pair<Edge,Point>(e1,p3));
						 p2.list.add(new Pair<Edge,Point>(e3,p1));
						 p3.list.add(new Pair<Edge,Point>(e1,p2));
						 p3.list.add(new Pair<Edge,Point>(e2,p1));
					 }
				 else {
					 p1.list.add(new Pair<Edge,Point>(e3,p2));
					p1.list.add(new Pair<Edge,Point>(e2,p3));
					p2.list.add(new Pair<Edge,Point>(e1,p3));
						 p2.list.add(new Pair<Edge,Point>(e3,p1));
						 p3.list.add(new Pair<Edge,Point>(e1,p2));
						 p3.list.add(new Pair<Edge,Point>(e2,p1)); 
				 }
				 
				 }
			 
			 else if((fp[0]==true&&fp[1]==true&&fp[2]==true)||(fp[0]==false&&fp[1]==true&&fp[2]==true)||(fp[0]==true&&fp[1]==true&&fp[2]==false)||(fp[0]==true&&fp[2]==true&&fp[1]==false)) {
				 for(int i=0; i<3; i++) {
					 int hashcode= mod((e[i].hashCode())%parray.length);
					 if(earray[hashcode]==null) {
						earray[hashcode]= new BinarySearchTree(e[i],e[i]);
						elist.add(e[i]);
						e[i].tlist.add(t);
					 }
					 else {
						 Position<Edge,Edge> p=earray[hashcode].search(e[i],earray[hashcode].root);
						 if(p.key.compareTo(e[i])==0) {
							 fe[i]=true;
							 for(int j=0;j<p.value.tlist.count;j++) {
								 Triangle t1=p.value.tlist.get(j);
								 t.list.add(t1);
								 t1.list.add(t);
							 }
							 p.value.tlist.add(t);
						 }
						 else {
							 earray[hashcode].insert(e[i],e[i]);
							 elist.add(e[i]);
							 e[i].tlist.add(t);
							 }
					 }
				 }
				 if(fp[0]==false) {
					 int hashcode= mod((p2.hashCode())%parray.length); 
					 p2=parray[hashcode].search(p2,parray[hashcode].root).value;
					 hashcode=mod((p3.hashCode())%parray.length); 
					 p3=parray[hashcode].search(p3,parray[hashcode].root).value;
					 p1.list.add(new Pair<Edge,Point>(e2,p3));
					 p3.list.add(new Pair<Edge,Point>(e2,p1));
					 p1.list.add(new Pair<Edge,Point>(e3,p2));
					 p2.list.add(new Pair<Edge,Point>(e3,p1));
					 if(fe[0]==false) {
						 p2.list.add(new Pair<Edge,Point>(e1,p3));
						 p3.list.add(new Pair<Edge,Point>(e1,p2));
					 }
						
				 }
				 else if(fp[1]==false) {
					 int hashcode= mod((p1.hashCode())%parray.length); 
					 p1=parray[hashcode].search(p1,parray[hashcode].root).value;
					 hashcode=mod((p3.hashCode())%parray.length); 
					 p3=parray[hashcode].search(p3,parray[hashcode].root).value;
					 p2.list.add(new Pair<Edge,Point>(e1,p3));
					 p3.list.add(new Pair<Edge,Point>(e1,p2));
					 p1.list.add(new Pair<Edge,Point>(e3,p2));
					 p2.list.add(new Pair<Edge,Point>(e3,p1));
					 if(fe[1]==false) {
						 p1.list.add(new Pair<Edge,Point>(e2,p3));
						 p3.list.add(new Pair<Edge,Point>(e2,p1));
					 }
					 }
				 else if(fp[2]==false) {
					 int hashcode= mod((p1.hashCode())%parray.length); 
					 p1=parray[hashcode].search(p1,parray[hashcode].root).value;
					 hashcode=mod((p2.hashCode())%parray.length); 
					 p2=parray[hashcode].search(p2,parray[hashcode].root).value; 
					 p2.list.add(new Pair<Edge,Point>(e1,p3));
					 p3.list.add(new Pair<Edge,Point>(e1,p2));
					 p1.list.add(new Pair<Edge,Point>(e2,p3));
					 p3.list.add(new Pair<Edge,Point>(e2,p1));
					 if(fe[2]==false) {
						 p1.list.add(new Pair<Edge,Point>(e3,p2));
						 p2.list.add(new Pair<Edge,Point>(e3,p1));
					 }
				 }
				 else {
					 if(fe[0]==false) {
						 p2.list.add(new Pair<Edge,Point>(e1,p3));
						 p3.list.add(new Pair<Edge,Point>(e1,p2));
					 }
					 if(fe[1]==false) {
						 p1.list.add(new Pair<Edge,Point>(e2,p3));
						 p3.list.add(new Pair<Edge,Point>(e2,p1));
					 }
					 if(fe[2]==false) {
						 p1.list.add(new Pair<Edge,Point>(e3,p2));
						 p2.list.add(new Pair<Edge,Point>(e3,p1));
					 }
					 }
			 }
			 
			 
			 return true;
		 }
		 return false;
		 }
	 public int TYPE_MESH(){
		 boolean sp=false;
		 int i=0;
		 for(i=0;i<elist.count;i++) {
			 Edge e=elist.get(i);
			 if(e.tlist.count>2) {
				 return 3;
			 }
			 else if(e.tlist.count==1) {
				 sp=true;
			 }
			 else {
			 }
			 }
		 if(sp==true) {
			 return 2;
		 }
		 else {
			 return 1;
		 }
		 }
	 public EdgeInterface [] BOUNDARY_EDGES(){
		 ArrayList<Edge> args= new ArrayList();
		 int i=0;
		 for(i=0;i<elist.count;i++) {
			 Edge e= elist.get(i);
			 if(e.tlist.count==1) {
				 args.add(e);
				 int j= args.count-1;
				 while(j>0) {
					 if(((Edge) args.get(j-1)).length()>e.length()) {
						 args.set(j,args.get(j-1) );
						 args.set(j-1, e);
						 j--;
					 }
					 else {
						 break;
					 }
				 }
			 }
		 }
		 EdgeInterface[] args1= new EdgeInterface[args.count];
		 for(i=0;i<args1.length;i++) {
			 args1[i]=args.get(i);
		 }
		 if(args1.length==0) {
			 return null;
		 }
		 return args1;
		 }
	 public TriangleInterface [] INCIDENT_TRIANGLES(float [] point_coordinates){
		 Point p= new Point(point_coordinates[0],point_coordinates[1],point_coordinates[2]);
		 int hashCode= mod(p.hashCode()%parray.length);
		 Position<Point,Point> pos=parray[hashCode].search(p, parray[hashCode].root);
		 if(pos.key.compareTo(p)==0) {
			 TriangleInterface[] args= new TriangleInterface[pos.value.tlist.count]; 
			 for(int i=0;i<pos.value.tlist.count;i++) {
				 args[i]=pos.value.tlist.get(i);
			 }
			 return args;
		 }
		 else {
			 return null;
		 }
		 }
	 public TriangleInterface [] TRIANGLE_NEIGHBOR_OF_EDGE(float [] edge_coordinates){ 
		 Point p1= new Point(edge_coordinates[0],edge_coordinates[1],edge_coordinates[2]);
		 Point p2= new Point(edge_coordinates[3],edge_coordinates[4],edge_coordinates[5]);
		 Edge e= new Edge(p1,p2);
		 int hashCode= mod(e.hashCode()%parray.length);
		 Position<Edge,Edge> pos=earray[hashCode].search(e, earray[hashCode].root);
		 if(pos.key.compareTo(e)==0) {
			 TriangleInterface[] args= new TriangleInterface[pos.value.tlist.count]; 
			 for(int i=0;i<pos.value.tlist.count;i++) {
				 args[i]=pos.value.tlist.get(i);
			 }
			 return args;
		 }
		 else {
			 return null;
		 }
		 }
	 public PointInterface [] NEIGHBORS_OF_POINT(float [] point_coordinates){
		 Point p= new Point(point_coordinates[0],point_coordinates[1],point_coordinates[2]);
		 int hashCode= mod(p.hashCode()%parray.length);
		 Position<Point,Point> pos=parray[hashCode].search(p, parray[hashCode].root);
		 if(pos.key.compareTo(p)==0) {
			 PointInterface[] args= new PointInterface[pos.value.list.count]; 
			 for(int i=0;i<pos.value.list.count;i++) {
				 args[i]=(Point) ((Pair)pos.value.list.get(i)).second;
			 }
			 return args;
		 }
		 else {
			 return null;
		 }
		 }
	 public PointInterface [] VERTEX_NEIGHBOR_TRIANGLE(float [] triangle_coord){
		 Point p1= new Point(triangle_coord[0],triangle_coord[1],triangle_coord[2]);
		 Point p2= new Point(triangle_coord[3],triangle_coord[4],triangle_coord[5]);
		 Point p3= new Point(triangle_coord[6],triangle_coord[7],triangle_coord[8]);
		 Triangle t= new Triangle(p1,p2,p3);
		 int hash= mod(t.hashCode()%tarray.length);
		 if(tarray[hash]==null) {
			 return null;
		 }
		 Position<Triangle,Triangle> pos= tarray[hash].search(t, tarray[hash].root);
		 if(pos.value.compareTo(t)==0) {
			 t=pos.value;
			 return t.triangle_coord();
		 }
		 return null;
		 }
	 public EdgeInterface [] EDGE_NEIGHBOR_TRIANGLE(float [] triangle_coord){
		 Point p1= new Point(triangle_coord[0],triangle_coord[1],triangle_coord[2]);
		 Point p2= new Point(triangle_coord[3],triangle_coord[4],triangle_coord[5]);
		 Point p3= new Point(triangle_coord[6],triangle_coord[7],triangle_coord[8]);
		 Triangle t= new Triangle(p1,p2,p3);
		 int hash= mod(t.hashCode()%tarray.length);
		 if(tarray[hash]==null) {
			 return null;
		 }
		 Position<Triangle,Triangle> pos= tarray[hash].search(t, tarray[hash].root);
		 if(pos.value.compareTo(t)==0) {
			 t=pos.value;
			 return t.triangle_edge();
		 }
		 return null;
		 }
	 public EdgeInterface [] EDGE_NEIGHBORS_OF_POINT(float [] point_coordinates){
		 Point p= new Point(point_coordinates[0],point_coordinates[1],point_coordinates[2]);
		 int hashCode= mod(p.hashCode()%parray.length);
		 if(parray[hashCode]==null) {
			 return null;
		 }
		 Position<Point,Point> pos=parray[hashCode].search(p, parray[hashCode].root);
		 if(pos.key.compareTo(p)==0) {
			 EdgeInterface[] args= new EdgeInterface[pos.value.list.count]; 
			 for(int i=0;i<pos.value.list.count;i++) {
				 args[i]=(Edge) ((Pair) pos.value.list.get(i)).first;
			 }
			 return args;
		 }
			 return null;
		 }
	 public TriangleInterface [] FACE_NEIGHBORS_OF_POINT(float [] point_coordinates){
		 Point p= new Point(point_coordinates[0],point_coordinates[1],point_coordinates[2]);
		 int hashCode= mod(p.hashCode()%parray.length);
		 if(parray[hashCode]==null) {
			 return null;
		 }
		 Position<Point,Point> pos=parray[hashCode].search(p, parray[hashCode].root);
		 if(pos.key.compareTo(p)==0) {
			 TriangleInterface[] args= new TriangleInterface[pos.value.tlist.count]; 
			 for(int i=0;i<pos.value.tlist.count;i++) {
				 args[i]=pos.value.tlist.get(i);
			 }
			 return args;
		 }
		 return null;
		 }
	 public TriangleInterface [] EXTENDED_NEIGHBOR_TRIANGLE(float [] triangle_coord){
		 Point p1= new Point(triangle_coord[0],triangle_coord[1],triangle_coord[2]);
		 Point p2= new Point(triangle_coord[3],triangle_coord[4],triangle_coord[5]);
		 Point p3= new Point(triangle_coord[6],triangle_coord[7],triangle_coord[8]);
		 Triangle t= new Triangle(p1,p2,p3);
		 int hash= mod(t.hashCode()%tarray.length);
		 if(tarray[hash]==null) {
			 return null;
		 }
		 Position<Triangle,Triangle> pos= tarray[hash].search(t, tarray[hash].root);
		 if(pos.value.compareTo(t)==0) {
			 ArrayList<Triangle> list= new ArrayList();
			 t=pos.value;
			 PointInterface[] edges=t.triangle_coord();
			 for(int i=0;i<edges.length;i++) {
				 for(int j=0;j<((Point)edges[i]).tlist.count;j++) {
					 if(list.contains(((Point)edges[i]).tlist.get(j))||((Point)edges[i]).tlist.get(j).compareTo(t)==0) {
						 }
					 else {
						 list.add(((Point)edges[i]).tlist.get(j));
						 int index=list.count-1;
						 while(index>0) {
							 Triangle t1=list.get(index-1);
							 Triangle t2=list.get(index);
							 if(t1.actualtime>t2.actualtime) {
								 list.set(index,t1);
								 list.set(index-1,t2);
								 index--;
							 }
							 else {
								 break;
							 }
						 }
					 }
				 }
			 }
			 TriangleInterface[] args1=new TriangleInterface[list.count];
				for(int i=0;i<list.count;i++) {
					args1[i]=list.get(i);
				}
				return args1; 
		 }
		 return null;
		 }
	 public TriangleInterface [] NEIGHBORS_OF_TRIANGLE(float [] triangle_coord){
		 Point p1= new Point(triangle_coord[0],triangle_coord[1],triangle_coord[2]);
		 Point p2= new Point(triangle_coord[3],triangle_coord[4],triangle_coord[5]);
		 Point p3= new Point(triangle_coord[6],triangle_coord[7],triangle_coord[8]);
		 Triangle t= new Triangle(p1,p2,p3);
		 int hash= mod(t.hashCode()%tarray.length);
		 if(tarray[hash]==null) {
			 return null;
		 }
		 Position<Triangle,Triangle> pos= tarray[hash].search(t, tarray[hash].root);
		 if(pos.value.compareTo(t)==0) {
			 ArrayList<Triangle> list= new ArrayList<Triangle>();
			 t=pos.value;
			 for(int i=0;i<t.list.count;i++) {
				 list.add(t.list.get(i));
				 int index=list.count-1;
				 while(index>0) {
					 Triangle t1=list.get(index-1);
					 Triangle t2=list.get(index);
					 if(t1.actualtime>t2.actualtime) {
						 list.set(index,t1);
						 list.set(index-1,t2);
						 index--;
					 }
					 else {
						 break;
					 }
				 }
			 }
			 TriangleInterface[] args1=new TriangleInterface[list.count];
				for(int i=0;i<list.count;i++) {
					args1[i]=list.get(i);
				}
				return args1; 
		 }
		 return null;
		 }
	 public int COUNT_CONNECTED_COMPONENTS(){
		 component=0;
		 ArrayList<Pair<ArrayList<Triangle>,ArrayList<Point>>> conn_comp= new ArrayList<Pair<ArrayList<Triangle>,ArrayList<Point>>>();
		 Triangle t= tlist.get(0);
		 ArrayList<Triangle> parent= tlist;
		 BFScount++;
		 Pair<ArrayList<Triangle>,ArrayList<Point>> list= BFS(t);
		 int total=list.first.count;
		 conn_comp.add(list);
		 while(total<not) {
			 ArrayList<Triangle> child= new ArrayList<Triangle>();
			 for(int i=0;i<parent.count;i++) {
				 if(parent.get(i).count<BFScount) {
					 child.add(parent.get(i));
				 }
			 }
			 parent=child;
			 t= child.get(0);
			 BFScount++;
			 component++;
			 list= BFS(t);
			 conn_comp.add(list);
			 total+=list.first.count;
		 }
		 conn_comp1=conn_comp;
		 return conn_comp.count;
		 }
	 
	 public PointInterface [] CENTROID(){
		 COUNT_CONNECTED_COMPONENTS();
		 PointInterface[] array=new PointInterface[conn_comp1.count];
		 int i=0;
		 while(i<conn_comp1.count) {
			float x=0,y=0,z=0;
				int nov=0;
				ArrayList<Point> pos= conn_comp1.get(i).second;
				for(int m=0;m<pos.count;m++) {
					x+=pos.get(m).getX();
					y+=pos.get(m).getY();
					z+=pos.get(m).getZ();
					nov++;
					
				}
				Point p=new Point(x/nov,y/nov,z/nov);
				array[i]=p;
				i++;
				}
		 if(array.length>0) {
			 return array;
		 }
		 return null;
		 }
	 public PointInterface CENTROID_OF_COMPONENT (float [] point_coordinates){
		 COUNT_CONNECTED_COMPONENTS();
		 Point p= new Point(point_coordinates[0],point_coordinates[1],point_coordinates[2]);
		 int hash=mod(p.hashCode()%parray.length);
		 if(parray[hash]==null) {
			 return null;
		 }
		 Point p1= parray[hash].search(p, parray[hash].root).value;
		 if(p1.compareTo(p)==0) {
			float x=0,y=0,z=0;
			int nov=0;
			ArrayList<Point> pos=conn_comp1.get(p1.component).getSecond();
			for(int m=0;m<pos.count;m++) {
				x+=pos.get(m).getX();
				y+=pos.get(m).getY();
				z+=pos.get(m).getZ();
				nov++;
				
			}
			PointInterface centroid= new Point(x/nov,y/nov,z/nov);
			return centroid;
		 }
		 return null;
		 }
	 public boolean IS_CONNECTED(float [] triangle_coord_1, float [] triangle_coord_2){
		 isconn--;
		 component=isconn;
		 Point p1= new Point(triangle_coord_1[0],triangle_coord_1[1],triangle_coord_1[2]);
		 Point p2= new Point(triangle_coord_1[3],triangle_coord_1[4],triangle_coord_1[5]);
		 Point p3= new Point(triangle_coord_1[6],triangle_coord_1[7],triangle_coord_1[8]);
		 Point p4= new Point(triangle_coord_2[0],triangle_coord_2[1],triangle_coord_2[2]);
		 Point p5= new Point(triangle_coord_2[3],triangle_coord_2[4],triangle_coord_2[5]);
		 Point p6= new Point(triangle_coord_2[6],triangle_coord_2[7],triangle_coord_2[8]);
		 Triangle t1= new Triangle(p1,p2,p3);
		 Triangle t2= new Triangle(p4,p5,p6);
		 int hash=mod(t1.hashCode()%tarray.length);
		 if(tarray[hash]==null) {
			 return false;
		 }
		 Triangle pos= tarray[hash].search(t1, tarray[hash].root).value;
		 if(pos.compareTo(t1)==0) {
			 hash=mod(t2.hashCode()%tarray.length); 
			 if(tarray[hash]==null) {
				 return false;
			 }
			 Triangle pos1= tarray[hash].search(t2, tarray[hash].root).value;
			 if(pos1.compareTo(t2)==0) {
				 BFScount++;
				BFS(pos);
				if(pos.component==pos1.component) {
					return true;
				}
			 }
			 }
		 return false;
		 }
	 public PointInterface [] CLOSEST_COMPONENTS(){
		 COUNT_CONNECTED_COMPONENTS();
		 double min_dis=Double.MAX_VALUE,dis=0;
		 PointInterface[] close= new PointInterface[2];
		 for(int i=0;i<conn_comp1.count;i++) {
			 ArrayList<Point> pos= conn_comp1.get(i).getSecond();
			 for(int j=i+1;j<conn_comp1.count;j++) {
				 ArrayList<Point> pos1= conn_comp1.get(j).getSecond(); 
				 for(int x=0;x<pos.count;x++) {
					 Point p=pos.get(x);
					 for(int y=0;y<pos1.count;y++) {
						 Point q= pos1.get(y);
						 dis= p.length(q);
						 if(dis<min_dis) {
							 min_dis=dis;
							 close[0]=p;
							 close[1]=q;
						 }
					 }
				 }
			 }
		 }
		 
		 return close;
		 }
	 public int MAXIMUM_DIAMETER(){
		 COUNT_CONNECTED_COMPONENTS();
		 int max=0,x=0;
		 for(int i=0;i<conn_comp1.count;i++) {
			 if(conn_comp1.get(i).first.count>max) {
				 max=conn_comp1.get(i).first.count;
				 x=i;
			 }
		 }
		 if(max==1) {
			 return 0;
		 }
		 else {
			ArrayList<Triangle> maxlist= conn_comp1.get(x).first;
			return maxlist.levels;
			
		 }
		 }

	 

}

