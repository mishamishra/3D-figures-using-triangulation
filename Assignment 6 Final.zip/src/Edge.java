
public class Edge implements EdgeInterface, Comparable<Edge>{
	 public static int mod(int num) {
		 if(num<0) {
			 return (-1)*num;
		 }
		 else {
			 return num;
		 }
	 }
	 public static float sq(float num) {
		 return num*num;
		 }
	 public static float sqrt(float num) {
		 float temp;
		 float sr = num / 2;
		 do {
			 temp = sr;
				sr = (temp + (num / temp)) / 2;
			} while ((temp - sr) != 0);
		 return sr;
	 }
	Point p1,p2;
	long actualtime;
	ArrayList<Triangle> tlist= new ArrayList<Triangle>();
	@Override
	public int hashCode() {
		return mod(p1.hashCode()+p2.hashCode());
	}
	Edge(Point p1, Point p2){
		this.p1=p1;
		this.p2=p2;
		this.actualtime=System.nanoTime();
	}
	double length() {
		return Math.sqrt(sq(p1.x-p2.x)+sq(p1.y-p2.y)+sq(p1.z-p2.z));
	}
	public PointInterface [] edgeEndPoints() {
			PointInterface[] endpoints= {p1,p2};
			return endpoints;
		}
	public String toString() {
		return "["+p1.toString()+","+p2.toString()+"]";
	}
	public int compareTo(Edge e) {
			if(this.p1.compareTo(e.p1)==0&&this.p2.compareTo(e.p2)==0) {
				return 0;
			}
			else if(this.p1.compareTo(e.p2)==0&&this.p2.compareTo(e.p1)==0) {
				return 0;
			}
			else {
				if(this.length()<e.length()) {
					return -1;
				}
				else if(this.length()>e.length()) {
					return 1;
				}
				else {
					if(this.actualtime<e.actualtime) {
						return -1;
					}
					else{
						return 1;
					}
				}
			}
		}
	public boolean equals(Edge e) {
		if(this.p1.compareTo(e.p1)==0&&this.p2.compareTo(e.p2)==0) {
			return true;
		}
		else if(this.p1.compareTo(e.p2)==0&&this.p2.compareTo(e.p1)==0) {
			return true;
		}
		return false;
	}
	}

