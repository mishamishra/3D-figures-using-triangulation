public class Triangle implements TriangleInterface,Comparable<Triangle>{
	 public static int mod(int num) {
		 if(num<0) {
			 return (-1)*num;
		 }
		 else {
			 return num;
		 }
	 }
	Point p1,p2,p3;
	Edge e1,e2,e3;
	long actualtime;
	int count,component;
	ArrayList<Triangle> list= new ArrayList<Triangle>();
	Triangle(Point p1, Point p2, Point p3){
		this.p1=p1;
		this.p2=p2;
		this.p3=p3;
		e1=new Edge(p1,p2);
		e2=new Edge(p1,p3);
		e3=new Edge(p3,p2);
		this.actualtime= System.nanoTime();
		count=0;
	}
	public PointInterface [] triangle_coord() {
			PointInterface[] endpoints= {p1,p2,p3};
			return endpoints;
		}
	public EdgeInterface [] triangle_edge() {
		EdgeInterface[] endpoints= {e1,e2,e3};
		return endpoints;
	}
	 @Override
	public int hashCode() {
		return mod(p1.hashCode()+p2.hashCode()+p3.hashCode());
	}
	public int compareTo(Triangle T) {
		 if(this.p1.compareTo(T.p1)==0&&this.p2.compareTo(T.p2)==0&&this.p3.compareTo(T.p3)==0) {
     		return 0;
     		}
		 else if(this.p1.compareTo(T.p1)==0&&this.p2.compareTo(T.p3)==0&&this.p3.compareTo(T.p2)==0) {
				return 0; 
			 }
		 else if(this.p1.compareTo(T.p2)==0&&this.p2.compareTo(T.p3)==0&&this.p3.compareTo(T.p1)==0) {
			return 0; 
		 }
		 else if(this.p1.compareTo(T.p2)==0&&this.p2.compareTo(T.p1)==0&&this.p3.compareTo(T.p3)==0) {
				return 0; 
			 }
		 else if(this.p1.compareTo(T.p3)==0&&this.p2.compareTo(T.p1)==0&&this.p3.compareTo(T.p2)==0) {
				return 0; 
			 }
		 else if(this.p1.compareTo(T.p3)==0&&this.p2.compareTo(T.p2)==0&&this.p3.compareTo(T.p1)==0) {
				return 0; 
			 }
		 else {
			 return 1;
		 }
     	
	 }
	public String toString() {
		return "["+p1.toString()+","+p2.toString()+","+p3.toString()+"]";
	}
	public boolean equals(Triangle T) {
		if(this.p1.compareTo(T.p1)==0&&this.p2.compareTo(T.p2)==0&&this.p3.compareTo(T.p3)==0) {
     		return true;
     		}
		 else if(this.p1.compareTo(T.p1)==0&&this.p2.compareTo(T.p3)==0&&this.p3.compareTo(T.p2)==0) {
				return true; 
			 }
		 else if(this.p1.compareTo(T.p2)==0&&this.p2.compareTo(T.p3)==0&&this.p3.compareTo(T.p1)==0) {
			return true; 
		 }
		 else if(this.p1.compareTo(T.p2)==0&&this.p2.compareTo(T.p1)==0&&this.p3.compareTo(T.p3)==0) {
				return true; 
			 }
		 else if(this.p1.compareTo(T.p3)==0&&this.p2.compareTo(T.p1)==0&&this.p3.compareTo(T.p2)==0) {
				return true; 
			 }
		 else if(this.p1.compareTo(T.p3)==0&&this.p2.compareTo(T.p2)==0&&this.p3.compareTo(T.p1)==0) {
				return true; 
			 }
		return false;
	}
}
